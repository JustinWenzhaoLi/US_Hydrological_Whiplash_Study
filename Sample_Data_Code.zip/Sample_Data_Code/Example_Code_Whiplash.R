# Copyright (c) 2024 Wenzhao Li, Chapman University
# Please Contact wli@chapman.edu

library(ggplot2)
library(dplyr)

# Set the working directory path
path <- getwd()

# Load HUC and station data
huc.df <- read.csv("RFC_HUC.csv")
carryover.df <- read.csv("Station_Stats_NLDAS_Station.csv")

# List all files in the data_final directory
file_list <- list.files(paste0(path, "/data_final"))

# Iterate through each file in the list
for (i in 1:length(file_list)) {
  
  # Read the current CSV file
  original.df <- read.csv(paste0(path, "/data_final/", file_list[i]))
  
  # Calculate the mean value for the years 1981-2020
  meanValue <- mean(original.df[original.df$Year %in% c(1981:2020),]$Value, na.rm=TRUE)
  
  # Process only if the mean value is greater than 10
  if (meanValue > 10) {
    
    # Filter the data for the years 1896-2023 and calculate anomalies
    original.df <- original.df[original.df$Year %in% c(1896:2023),]
    x <- original.df$Value - meanValue
    
    # Calculate the 20th and 80th percentiles for the years 1981-2020
    percentile20_80 <- quantile(original.df[original.df$Year %in% c(1981:2020),]$Value, probs = c(0.2, 0.8))
    upperLimit80 <- round(percentile20_80[2], 2) - meanValue
    
    # Initialize a new data frame with anomalies
    df <- data.frame(x)
    
    # Add additional columns for ID, accumulated value, indicator, and year
    df$n <- NA
    df$ID <- NA
    df$AccumValue <- NA
    df$Indicator <- NA
    df$Year <- original.df$Year
    
    # Initialize the first row
    df[1,]$ID <- 1 # Station ID
    df[1,]$AccumValue <- df[1,]$x # Accumulative Deficit or Surplus for one wet or dry period
    df[1,]$Indicator <- df[1,]$x # Indicator
    df[1,]$n <- 1 # Temporary variable counter to calculate the years of wet or dry periods as periodLength
    
    # Get the carryover factor for the current station
    k <- carryover.df[carryover.df$ID == original.df$ID[1],]$k
    
    # Error handling to continue in case of issues
    tryCatch({
      
      # Iterate through each row to update indicators and accumulate values
      for (p in 1:(nrow(df)-1)) {
        # Same wet/dry condition in the following year
        if (df[p,]$Indicator * df[p+1,]$x >= 0) {
          df[p+1,]$ID <- df[p,]$ID
          df[p+1,]$n <- df[p,]$n + 1
          df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*df[p,]$Indicator
          if(df[p,]$x > upperLimit80) {df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*upperLimit80}
          df[p+1,]$AccumValue <- df[p,]$AccumValue + df[p+1,]$Indicator
        } else {
          # Small shift that does not end the previous period
          if ((1-k)*abs(df[p+1,]$x) < k*abs(df[p,]$Indicator)) {
            df[p+1,]$ID <- df[p,]$ID
            df[p+1,]$n <- df[p,]$n + 1
            df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*df[p,]$Indicator
            if(df[p,]$x > upperLimit80) {df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*upperLimit80}
            df[p+1,]$AccumValue <- df[p,]$AccumValue + df[p+1,]$Indicator
          } else {
            # Big shift that ends the previous period
            df[p+1,]$ID <- df[p,]$ID + 1
            df[p+1,]$n <- 1
            df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*df[p,]$Indicator
            if(df[p,]$x > upperLimit80) {df[p+1,]$Indicator <- (1-k)*df[p+1,]$x + k*upperLimit80}
            df[p+1,]$AccumValue <- df[p+1,]$Indicator
          }
        }
      }
      
      # Determine the condition (Surplus or Deficit) based on the indicator
      df$Condition <- ifelse(df$Indicator >= 0, 'Surplus', 'Deficit')
      
      # Calculate percentiles for Water Year Type (WYT) classification
      percentile_WYT <- quantile(df[df$Year %in% c(1981:2020),]$Indicator, probs = c(0.15, 0.3, 0.5, 0.7))
      df$WYT <- ifelse(df$Indicator <= percentile_WYT[1], 'C', 
                       ifelse(df$Indicator <= percentile_WYT[2], 'D', 
                              ifelse(df$Indicator <= percentile_WYT[3], 'BN', 
                                     ifelse(df$Indicator <= percentile_WYT[4], 'AN', 'W'))))
      
      # Add mean value and ratio columns
      df$meanValue <- meanValue # Mean of 1981-2020
      df$ratio <- df$Indicator / meanValue # Ratio of Indicator to meanValue
      
      # Prepare the export data frame and rename columns
      export.df <- df
      names(export.df) <- c("Anomalies", "PeriodLength", "PeriodID", "AccumValue", "Indicator", "Year", "Condition", "WYT", "meanValue", "ratio")
      
      # Calculate the standard deviation for the years 1981-2020
      std <- sd(export.df[export.df$Year %in% c(1981:2020),]$ratio, na.rm=TRUE)
      
      # Add columns for ratio difference, previous period length, and whiplash identification
      export.df$Ratio_Diff <- c(0, diff(export.df$ratio))
      export.df$Previous_PeriodLength <- c(0, export.df$PeriodLength[-length(export.df$PeriodLength)])
      export.df$Whiplash <- NA
      
      # Identify whiplash years based on ratio and indicator conditions
      percentile20_80 <- quantile(export.df[export.df$Year %in% c(1981:2020),]$ratio, probs = c(0.2, 0.8))
      for (j in export.df$Year[2:nrow(export.df)]) {
        if ((export.df[export.df$Year == j-1,]$ratio >= round(percentile20_80[2], 2)) &  
            (export.df[export.df$Year == j,]$ratio <= round(percentile20_80[1], 2)) & 
            (export.df[export.df$Year == j-1,]$Indicator * export.df[export.df$Year == j,]$Indicator < 0)) {
          export.df[export.df$Year == j,]$Whiplash <- export.df[export.df$Year == j,]$ratio
        }
        if ((export.df[export.df$Year == j,]$ratio >= round(percentile20_80[2], 2)) &  
            (export.df[export.df$Year == j-1,]$ratio <= round(percentile20_80[1], 2)) & 
            (export.df[export.df$Year == j-1,]$Indicator * export.df[export.df$Year == j,]$Indicator < 0)) {
          export.df[export.df$Year == j,]$Whiplash <- export.df[export.df$Year == j,]$ratio
        }
      }
      
      # Assign original ID and flag to the export data frame
      export.df$ID <- original.df$ID
      export.df$Flag <- original.df$Flag
      export.df <- export.df %>%
        mutate(Flag = case_when(
          Flag == "P" ~ "Estimated",
          Flag == "A" ~ "Actual",
          TRUE ~ Flag  # Keep all other values unchanged
        ))
      
      # Write the processed data to a CSV file
      write.csv(export.df, paste0(path, "/export/", 'Gauge_', export.df$ID[1], '_20_80p.csv'), row.names = FALSE)
      
    }, error=function(e){cat("ERROR:", original.df$ID[1], "\n")})
  }
}
